# 麒麟集团

```shell
composer require kylin/modules
php artisan vendor:publish --provider="Kylin\Modules\LaravelModulesServiceProvider"
```
