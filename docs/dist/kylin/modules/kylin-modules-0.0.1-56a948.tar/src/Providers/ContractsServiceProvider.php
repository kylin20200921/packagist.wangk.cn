<?php

namespace Kylin\Modules\Providers;

use Illuminate\Support\ServiceProvider;
use Kylin\Modules\Contracts\RepositoryInterface;
use Kylin\Modules\Laravel\LaravelFileRepository;

class ContractsServiceProvider extends ServiceProvider
{
    /**
     * Register some binding.
     */
    public function register()
    {
        $this->app->bind(RepositoryInterface::class, LaravelFileRepository::class);
    }
}
