<?php

namespace Kylin\Modules\Generators;

abstract class Generator
{
}
