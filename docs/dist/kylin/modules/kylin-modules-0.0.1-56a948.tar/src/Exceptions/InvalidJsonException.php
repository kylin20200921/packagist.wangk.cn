<?php

namespace Kylin\Modules\Exceptions;

class InvalidJsonException extends \Exception
{
}
