<?php

namespace Kylin\Modules\Exceptions;

class ModuleNotFoundException extends \Exception
{
}
