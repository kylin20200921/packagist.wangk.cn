<?php

namespace Kylin\Modules\Exceptions;

class FileAlreadyExistException extends \Exception
{
}
