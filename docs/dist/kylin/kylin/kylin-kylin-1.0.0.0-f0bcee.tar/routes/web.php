<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['firewall.all'])->group(function () {
    Route::get('/', function () {
        return view('welcome');
    });
});
