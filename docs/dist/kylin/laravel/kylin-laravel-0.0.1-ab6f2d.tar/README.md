# Kylin Admin

## 使用

```
composer create-project --prefer-dist kylin/laravel admin
```

